<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Zamówienia</title>
</head>
<body>

<h2>Zamówienia</h2>

<a href="index.php">Strona główna</a> | <a href="products.php">Produkty</a> | <a href="orders.php">Zamówienia</a> | <a href="groups.php">Grupy produktów</a> | <a href="users.php">Użytkownicy</a>

</body>
</html>