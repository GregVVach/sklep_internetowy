<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Koszyk</title>
</head>
<body>

<h2>Koszyk</h2>

<a href="index.php">Strona główna</a> | <a href="basket.php">Koszyk</a> | <a href="order.php">Zamówienia</a> | <a href="register.php">Rejestracja</a> | <a href="user.php">Dane użytkownika</a> | <a href="product.php">Szczegóły produktu</a>
 
</body>
</html>