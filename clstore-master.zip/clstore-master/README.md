# Warsztaty IV Sklep Internetowy
Projekt prostego sklepu internetowego, napisany z wykorzystaniem technik obiektowych.
